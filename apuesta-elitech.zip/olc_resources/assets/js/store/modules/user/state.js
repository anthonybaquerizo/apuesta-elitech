export default () => {
    return {
        id: 0,
        user_type_id: 0,
        email: '',
        password: '',
        name: '',
        last_name: '',
        phone: '',
        created_at: '',
        updated_at: ''
    }
}