export default () => {
    return {
        id: 0,
        name: '',
        status: 2,
        created_at: '',
        matches: []
    }
}