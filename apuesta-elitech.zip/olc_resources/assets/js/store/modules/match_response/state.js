export default () => {
    return {
        responses: [],
        name: '',
        status: 3,
        created_at: ''
    }
}