export default {
    /**
     * Devuelve los partidos jugados
     */
    getMatchResponses ({ commit }) {
        
    }
}