export default {
    setResponses (state, responses) {
        state.responses = responses
    }
}