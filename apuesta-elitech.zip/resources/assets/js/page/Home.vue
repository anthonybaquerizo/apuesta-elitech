<template lang="pug">
div.row
    div.col-lg-8.col-md-8.col-sm-8.col-12
        div.card
            div.card-header
                h3 <i class="fa fa-life-saver" ></i> Partidos
    div.col-lg-4.col-md-4.col-sm-4.col-12
        div.card
            div.card-header
                h3 <i class="fa fa-calculator" ></i> Apuesta
</template>

<script>
export default {
    name: 'Home'
}
</script>